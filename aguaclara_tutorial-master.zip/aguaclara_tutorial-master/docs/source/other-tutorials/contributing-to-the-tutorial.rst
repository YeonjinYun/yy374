.. _contributing-to-the-tutorial:

****************************
Contributing to the Tutorial
****************************

#. Go to the ``aguaclara_tutorial`` `repository's issues page <https://github.com/AguaClara/aguaclara_tutorial/issues>`_.
#. Open a "New Issue", detailing what you would like to add (or what you would like to see added) to the tutorial.
#. Add the label "addition" and tag ``oliver-leung`` to the issue body.
