.. _saving-markdown-to-pdf:

**********************
Saving Markdown to PDF
**********************

#. Open **Atom**, open the Markdown file that you want to convert, and open
   the formatted preview (``Ctrl + Shift + M``).
#. Right click on the formatted preview and click on "Open in Browser".
#. Right click on the browser page and click on "Print..."
#. Change the Destination to "Save as PDF", then click Save/Print.

**Now, save** ``Interactive-Tutorial-1-Markdown.md`` **as a PDF and put it in
your** ``aguaclara_tutorial`` **repository folder.**
