# AguaClara Tutorial

Welcome to the AguaClara Tutorial repository! Here, you'll find useful tutorials and guides on how to use AguaClara's software tools, such as Python, ProCoDA, and more.

## Using the tutorial

***Don't start here!*** Visit the [AguaClara Tutorial wiki](https://aguaclara.github.io/aguaclara_tutorial/) and follow the instructions there.